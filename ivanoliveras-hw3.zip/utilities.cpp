/*
By
Feb 2, 2019 - COP 3014
Program that implements the requirements of homework 3
*/
#include <math.h>
#include "utilities.h"
// This function will add the even positive integers from 0 to highNum
// and return the summed value. 
// If the value of highNum is negative, then a 0 should be returned.
int addEvenIntegers(int highNum)
{
	int sum = 0;  //  create sum integer to sum numbers
	if (highNum < 0)
	{
		return 0;  //  if number is negative, return 0
	}
	else
	{
		for (int i = 0; i <= highNum; i++)  //test numbers 1-highNum
		{
			if (0 == i % 2)  // if i is even
			{
				sum = sum + i;  //  sum i
			}
		}
		return sum;  //  return sum
	}
}

// This function will add the even positive integers from lowNum to highNum inclusive
// and return that sum. 
// If the value of highNum is negative then a 0 is returned
// If the value of lowNum is negative then a 0 is returned
// If highNum < lowNum then a 0 is returned.
// 
int addEvenIntegers(int lowNum, int highNum)
{
	int sum = 0;//create sum integer to sum numbers
	if ((highNum < 0)||(lowNum < 0)||(highNum<lowNum)) 
	{
		return 0;  //if numbers are negative or highNum is actually the lower number return 0
	}
	else
	{
		for (int i = lowNum; i <= highNum; i++)
		{
			if (0 == i % 2)  // if i is even
			{
				sum = sum + i;  //  sum i
			}
		}
		return sum;
	}
}

// This function will add 1 to an ASCII digit between '0' and '9' inclusive.
// ch is a character.
// If ch is not an ASCII digit (between '0' and '9' inclusive) then the same digit is returned (no change).
// If ch is between '0' and '8' then 1 is added and returned.
// If ch is '9' then the value of '0' must be returned.
char addOneToDigit(char ch)
{
	if (ch < '9' && ch >= '0')
	{
		ch = ch + 1;  //  if the character is less than 9 and bigger or equal than 0, return the next character in ASCII table (character+1)

		return ch;
	}
	else if (ch == '9')
	{
		return '0';  //  if character = 9 return character 0 (loops back)
	}
	else
	{
		return ch;  // if the character is not a number, do not sum the character and return the value
	}
}

// This function will return the monthly mortgage loan amount.
// loanAmount is the amount of the loan in dollars
// yearlyInterestRate is the yearly interest rate as a percent
// loanLength is the length of the loan in years
// If the loanAmount is <= 0 then return a -1.0
// If the yearlyInterestRate < 0 then return a -1.0
// If the yearlyInterestRate > 100 then return a -1.0
// If the loanLength <= 0 then return a -1.0
double getMortgagePayment(double loanAmount, double yearlyInterestRate, double loanLength)
{
	if (loanAmount <= 0 || yearlyInterestRate < 0 || yearlyInterestRate>100 || loanLength <= 0)
	{
		return -1.0;  //return -1.0 if any of the conditions in the if statement are met
	}
	else 
	{
		double monthlyPayments;  //used for formula
		double monthlyIR = 0;  //used for formula
		double mortgagePayment = 0;  //final formula
		monthlyPayments = loanLength * 12;  //Convert yearly payments to monthly payments
		monthlyIR = yearlyInterestRate / (12*100);  //convert yearly loan percentage interest rate to monthly loan decimal interest rate
		mortgagePayment = (loanAmount*monthlyIR) / (1 - (pow(1 + monthlyIR, -monthlyPayments)));  //formula for monthly mortgage payment
		return mortgagePayment;  
	}
}
