#ifndef UTILITIES_H  //make sure we don't define UTILITIES_H twice
#define UTILITIES_H  //creates UTILITIES_H 

char addOneToDigit(char ch);  //function prototype definitions
double getMortgagePayment(double loanAmount, double yearlyInterestRate, double loanLength);
int addEvenIntegers(int lowNum, int highNum);
int addEvenIntegers(int highNum);

#endif  //ends ifndef
