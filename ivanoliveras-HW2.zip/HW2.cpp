#include <iostream>  //for cout, cin
#include <math.h>  //for pow function
#include <iomanip>  //for manips
int main()
{
	const double MIN_LOAN_AMOUNT = 0;  //Minimum Loan Amount constant double
	const double MIN_LOAN_LENGTH = 0;  //Minimum Loan Length constant double
	const double MIN_LOAN_INTEREST = 0;  //Minimum Loan Interest constant double
	const double MAX_LOAN_INTEREST = 100;  //Minimum Loan Interest constant double
	double loanAmount = 200; //Loan Amount user input double
	double loanLength = 2;  //Loan Length user input double
	double loanIR = 1.2;  //Loan Interest Rate user input double
	const double MONTHS_PER_YEAR = 12;  //Conversion (12 Months per year) constant double
	const double PERCENTAGE_TO_DECIMAL = 100;  //Conversion (100%=1.0) constant double
	double mortgagePayment = 1020;  //calculated total monthly mortgage payment using formula
	double monthlyPayments = 12;  //calculated monthly payments using user input double
	double monthlyIR = .005;  //calculated monthly interest using user input double

	std::cout << "Hello, my name is Ivan Oliveras\nWelcome to the Mortgage Calculator!\nPlease enter the loan amount in dollars:" << std::endl;  //Name, Introduction, Ask user for loan in dollars
	std::cin >> loanAmount;  //input loanAmount
	std::cout << "Now Enter the length of the loan in years:" << std::endl;  //Ask user for length of loan in years
	std::cin >> loanLength;  //input loanLength
	std::cout << "Finally, enter the yearly interest rate as a percentage:" << std::endl;  //Ask user for yearly interest rate as a percentage
	std::cin >> loanIR;  //input loan IR
	if (loanAmount >= MIN_LOAN_AMOUNT && loanLength >= MIN_LOAN_LENGTH && (loanIR >= MIN_LOAN_INTEREST && loanIR <= MAX_LOAN_INTEREST))  //IF all the values are in the range we chose (depending on constants), calculate, otherwise display error and end program
	{
		monthlyPayments = loanLength * MONTHS_PER_YEAR;  //Convert yearly payments to monthly payments
		monthlyIR = loanIR / (MONTHS_PER_YEAR*PERCENTAGE_TO_DECIMAL);  //convert yearly loan percentage interest rate to monthly loan decimal interest rate
		mortgagePayment = (loanAmount*monthlyIR) / (1-(pow(1+monthlyIR,-monthlyPayments)));  //formula for monthly mortgage payment
		std::cout << "The monthly mortgage payment is: " << std::fixed<<std::setprecision(2)<<mortgagePayment;  //display to user mortgagePayment
	}
	else
	{
		std::cout << "ERROR, USER INPUT NOT IN RANGE" << std::endl;  //display error if user entered wrong values
	}
	return 0;
}