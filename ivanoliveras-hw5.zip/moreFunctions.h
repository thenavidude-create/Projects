#ifndef MOREFUNCTIONS_H
#define MOREFUNCTIONS_H

void arrayShiftRight(int *myArray, int arrayLength);
void getMatchingNumbers(const int *winners, const int *customerNumbers, int arrayLength, int &matches);
void trimArray(const char *toTrim, char *newArray);

#endif
