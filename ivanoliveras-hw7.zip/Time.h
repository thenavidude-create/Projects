#ifndef TIME_H
#define TIME_H
#include <new>
// the Time class type
class Time
{
public:
	Time();
	Time(int hoursP, int minutesP, int ampmP);
	~Time();
	int getHours() const; 
	int getMinutes() const;
	char getAMPM() const;
	void setTime(int hoursP, int minutesP, int ampmP);
private:
	int minutes;
	int *hours;
	char AMPM;
};
#endif