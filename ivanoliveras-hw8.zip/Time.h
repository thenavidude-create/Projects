
#ifndef TIME_H
#define TIME_H

#include <string>
#include <iostream>

// the Time type
class Time
{
public:
	// Constructors
	Time();
	Time(int hours, int minutes, char AM_PM);
	Time(const Time &copy);
	friend std::string getTimeString(const Time &str);
	// Destructor
	~Time();

	// accessors
	int getHours() const;
	int getMinutes() const;
	char getAMPM() const;


	// mutators
	void setTime(int hours, int minutes, char AM_PM);

private:
	// member variables
	int *hours;
	int minutes;
	char AM_PM;
};
//non-member non-friend countZeros() function
void countZeros(int h, int m, char AP, int &zeroCount);

#endif
