#ifndef MYARRAYFILE_H
#define MYARRAYFILE_H

int getRandomInteger(int max);
void quickPick(int myArray[]);
int getHighest(int myArray[], int arrayLength);
int addEvenPositive(int myArray[], int arrayLength);
bool isItemInArray(int myArray[], int arrayLength, int itemToFind);

#endif