/*
By
Feb 10, 2019 - COP 3014
Program that implements the requirements of homework 4
*/
#include "myarrayfile.h"
#include <ctime>    // For time()
#include <cstdlib>  // For srand() and rand()
// This function will perform a linear search of the input myArray[].
// arrayLength is the number of elements to search for in myArray[].
// If itemToFind is contained in myArray[] at least once then return true.
// If itemToFind is not contained in myArray[] then return false.
// If arrayLength is zero or negative then return false.
// You can only access the bounds of myArray, that is you only access between
// index 0 and index arrayLength-1.
bool isItemInArray(int myArray[], int arrayLength, int itemToFind)
{
	if (arrayLength <= 0)  
	{
		return false;  //if the array length specified is either 0 or less, return false because the function cannot detect the item in the Array because it's either 0 (no elements) or an invalid number of elements (negative)
	}
	for (int i = 0; i < arrayLength; i++)
	{
		if (myArray[i] == itemToFind)
		{
			return true;  //if the item you want to find in the array is there, return true, indicating that it is there
		}	
	}
	return false;
}

// This function will add all the even positive numbers in myArray.
// The length of myArray is defined by arrayLength.
// The value returned is the sum of all the even positive numbers in the array.
// If there are no positive even integers in the array then return 0.
// If arrayLength is zero or negative then return 0.
// You can only access the bounds of myArray, that is you only access between
// index 0 and index arrayLength-1.
int addEvenPositive(int myArray[], int arrayLength)
{
	int sum = 0;  // sum variable to sum even numbers in array
	if (arrayLength <= 0)
	{
		return 0;  //array length error
	}
	for (int i = 0; i < arrayLength; i++)
	{
		if (myArray[i] < 0)
		{
			// if the number in the array is negative, ignore it
		}
		else if (myArray[i] % 2 == 0)
		{
			sum = myArray[i] + sum;  // if the number in the array is positive and even, sum it.
		}
	}
	return sum;
}

// This function will find the highest value in myArray.
// The length of myArray is defined by arrayLength.
// The value returned is the highest value in myArray.
// If arrayLength is zero or negative then return 0.
// You can only access the bounds of myArray, that is you only access between
// index 0 and index arrayLength-1.
int getHighest(int myArray[], int arrayLength)
{
	if (arrayLength <= 0)
	{
		return 0;  // array length error
	}
	int highestNum = myArray[0];  //highestNum variable to hold highest number in array
	for (int i = 1; i < arrayLength; i++)
	{
		if (myArray[i] > highestNum)
		{
			highestNum = myArray[i];  //replace variable highestNum if the element in the array is higher than highestNum
		}
	}
	return highestNum;
}

// Implement a function that performs a quick pick function for the Florida Lottery.
// You are to fill myArray with six unique random numbers from 1 to 53.
// All the six numbers must be different. 
// You should use getRandomInteger(int) function which is provided to you.
// You can also use isItemInArray() function which is implemented above.
void quickPick(int myArray[])
{
	int arrayLength = 6;  // necessary for isItemInArray function, indicates the arrayLength
	int tempInt = 0;  //  necessary for do while loop, temporarily checks if this number is already in array.  
	for (int i = 0; i < arrayLength; i++)
	{
		do
		{
			tempInt = 1 + getRandomInteger(52);  //get random integer, but be careful, the function returns a number between 0 and max
		}
		while (isItemInArray(myArray, arrayLength, tempInt) == true);  // We create this because simply defining the myArray element in the do while will unfortunately include the same element in the isItemInArray function.  Once the random integer is not already in the array, the loop exits and the number is uesd.
		myArray[i] = tempInt;
	}
}


// do not make any changes to this function !!!
// getRandomInteger will return a random integer number between 0 and max
int getRandomInteger(int max)
{
	static bool initialized = false;
	if (initialized == false)
	{ // if the first time through then
		srand((unsigned)time(0));  // Initialize random number generator.
		initialized = true;
	}
	int rv = rand() % (max + 1);
	return rv;
}
